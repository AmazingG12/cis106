# Week Report 1

## Slack Screenshot

![Slack screenshot](image.png)

## Github Screenshot

![Github screenshot](image-1.png)

## Discussion Board Screenshot

![Discussion 1](image-2.png)

## Acknowledgements
* By submitting this assignment I [Gilda Hernandez] acknowledge that I have read the syllabus or home page of the course
* I also acknowledge that I have written down any questions that I have for the professor and will ask them in class or via Slack 
* I also acknowledge that I am aware that the final exam is In Person