In ruby to display text on the screen we use the `puts`method
In bash to do the same thing we use`echo`
and If i want to create a small program to print hello world i can do it like this:

In Ruby:

```ruby
puts"Hello World"
puts "This is my first program"
```

In bash:

```bash
echo "hello world"
echo "This is my first program"
```
