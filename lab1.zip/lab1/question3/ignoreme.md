![ignore me](https://assets.midnightcheese.com/gifs/ignore-me.gif)


# To do list for today
1. clean the house
2. do the dishes
3. do exercise
4. go visit family
5. watch netflix show

## Shopping list
* tomatoes
*  potoes
*  onions
*  meat

+ carrots
+ peas

- snacks
- coke
- pepsi
- water


