# Notes1

## What is Markdown?
Markdown is widely used and supported across different platform. Mark down is a simple way to format text using text symbols. It can use to create headings,paragraphs and links.Also supports formats such as images, tables and code formatting.

## What is Git?
Git allows use to save different versions of your work and return to an earlier version if needed.It allows fellow team members to work on the same project without overwriting each other's changes.

## What is GitHub?
GitHub is an online platform that lets you mange Git repositories. Not only that but as well lets you collaborate with others and share work. 

## What is Slack?
Slack is a platform that consist of communications and collaboration tools.It supports direct messaging, voice and video calls.
